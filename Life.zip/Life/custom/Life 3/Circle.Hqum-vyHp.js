module.exports = (node, graph) => {
	const triggerIn = node.triggerIn("in");

	triggerIn.onTrigger = (props) => {
		const { ctx, size } = props;

		// set background color to pale yellow
		ctx.fillStyle = `#FFFF66`;

		// set border color to black
		ctx.strokeStyle = "#000000";

		// start drawing shape
		ctx.beginPath();

		// draw a circle arc
		// at position 0,0
		// with radius half the size of cell gride
		// and from 0 to 360 degrees (full scircle)
		ctx.arc(0, 0, size / 2, 0, Math.PI * 2);

		// fill the shape
		ctx.fill();

		// add border to the shape
		ctx.stroke();

		// finish drawing shape
		ctx.closePath();
	};
  module.exports = (node, graph) => {
	const triggerIn = node.triggerIn("in");
	const triggerOut = node.triggerOut("out");

	let step = 50;

	// margin size in pixels
	const margin = 20;

	triggerIn.onTrigger = (props) => {
		const { canvas, ctx } = props;

		// save canvas state
		ctx.save();

		// start drawing clipping mask
		ctx.beginPath();

		// draw clipping mask rectangle slightly smaller than whole page
		ctx.rect(
			margin,
			margin,
			canvas.width - margin * 2,
			canvas.height - margin * 2
		);
		ctx.clip();

		for (let x = 0; x < canvas.width; x += step) {
			for (let y = 0; y < canvas.height; y += step) {
				ctx.save();
				ctx.translate(x, y);
				ctx.fillStyle = "#0000FC";
				ctx.fillRect(1, 1, step - 2, step - 2);
				ctx.restore();
			}
		}

		// restore canvas state effectively disabling clipping
		ctx.restore();
	};
};

};