module.exports = (node, graph) => {
	// create input trigger port we will use to receive data from parent node
	const triggerIn = node.triggerIn("in");
	// create output trigger port we will use to send data to child nodes
	const triggerOut = node.triggerOut("out");

	// size of each rectangles
	const step = 50;

	// we receive data from parent node on each frame
	// this is where we will draw our grid
	triggerIn.onTrigger = (props) => {
		// destructure canvas and context from the received properties
		const { canvas, ctx } = props;

		// draw a grid moving by "step" pixels to the right and down in a loop
		for (let x = 0; x < canvas.width; x += step) {
			for (let y = 0; y < canvas.height; y += step) {
				// save current canvas state
				ctx.save();

				// move "drawing pen" to x, y positions
				ctx.translate(x, y);

				// set fill color to Nodes Blue
				ctx.fillStyle = "#0001f2";

				// draw rectangle at the current "pen position"
				ctx.fillRect(1, 1, step - 2, step - 2);

				// restore canvas state to before translation
				ctx.restore();
			}
		}
	};
};